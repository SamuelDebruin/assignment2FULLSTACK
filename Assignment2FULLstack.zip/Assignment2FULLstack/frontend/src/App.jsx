import "./App.css";
import GroceriesApp from "./GroceriesApp";

function App() {
  return (
    <>
      <GroceriesApp />
    </>
  );
}

export default App;